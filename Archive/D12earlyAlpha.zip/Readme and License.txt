To install:
1.  Download and install the latest version of B9 Aerospace.
2.  Download and install the latest Firespitter plugin, also sounds if you like sounds for your choppers.
3.  Module Manager is helpful for community fixes.
4.  Install this folder from the pack exactly as you see it, it likes things to be in the tree structure that is here.
5.  Enjoy your stuff.  Let me know if there are any issues.

Note that this pack contains a rollup file for most B9 community fixes, save engines while I troubleshoot.  Please remove any other module managed fixes for B9 before installing or delete the CommunityFixes folder contained here.

This is a testing early alpha, be prepared to delete this and install a full release later.  I'll try to keep everything backwards compatible.

PolecatEZ



All original B9 work done by bac9-flcl (textures), Taverius (model)

This is released under identical license to the original B9 Aerospace pack.

The original B9 Aerospace pack is a REQUIRED dependency for this expansion pack.